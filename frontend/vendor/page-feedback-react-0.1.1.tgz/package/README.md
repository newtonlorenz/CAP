# Page Feedback for React

A small corner widget for bugs, ideas and general feedback. Optional element selection
captures a viewport screenshot with a numbered pin. Import the stylesheet once.

```tsx
import { FeedbackWidget } from '@page-feedback/react'
import '@page-feedback/react/style.css'

<FeedbackWidget
  pagePath={location.pathname}
  onSubmit={async report => {
    // Use your authenticated API client, including its CSRF protection.
    await yourApi.post('/feedback', report)
  }}
/>
```

The host backend forwards validated reports to Page Feedback with a private service key
and trusted identity headers. Never put that key in the browser. See the repository README.

Pass a changing `pagePath` from your SPA router. Navigation clears an old pin/screenshot;
draft text remains until sent or the widget unmounts. Key the widget by signed-in user ID.
No draft, screenshots, cookies, logs or session replay are stored in browser storage.

Screenshot capture uses html2canvas, dynamically imported only on request. It provides
viewport cropping and a detached-clone redaction hook. Inputs, textareas, selects,
editable regions and `[data-feedback-private]` are hidden in the captured clone.
Iframes, video and canvas content are excluded. Other visible page content is included:
mark sensitive sections yourself and let reporters review the preview before sending.
Complex CSS and cross-origin images may render imperfectly; text-only reporting remains available.

The widget is a non-modal dialog: Escape closes it and returns focus to the launcher.
For a pin, click the page or Tab to a control and press Enter. Escape cancels selection.
Capturing or submitting disables the form. An unchanged retry reuses the report UUID.

Customise `--pf-bg`, `--pf-text`, `--pf-muted`, `--pf-border`, `--pf-accent` on `.pf-root`.
Use selector specificity such as `:root .pf-root` to override the system dark-mode defaults.
The widget uses React portals and scoped CSS; it does not depend on Tailwind or a UI framework.

## Development

```sh
npm ci
NODE_OPTIONS=--no-experimental-webstorage npm test
npm run build
npm pack
```
